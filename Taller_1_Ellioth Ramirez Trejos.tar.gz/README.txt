INSTITUTO TECNOLOGICO DE COSTA RICA
ARQUITECTURA DE COMPUTADORES II
ELLIOTH RAMIREZ TREJOS 2014057732

TALLER 1 HILOS

Contenido
	Taller 1 hilos.pdf -> documento con las preinvestigación pedida.
	taller1.c	   -> archivo de C con el programa pedido.

Requerimientos 
	OS: Linux de 32 bits
	GCC
	Lenguaje C

Instrucciones
-> En la carpeta encontrara el archivo taller1.c
-> Abrir la terminal presionando, dentro de la carpeta, 
	click derecho y luego escoger la opción "abrir en
	terminal". 
-> Pegar el siguiente comando
	-$ gcc -pthread taller1.c

	Esto compilara el archivo taller1.c
-> Pegar el siguiente comando en la consola, en caso de que
	no reporte ningun error.
	-$ ./a.out

	Esto ejecutara el programa y empezara a imprimir el
	espacio del arreglo en conjunto con el dato que le 
	pertenece al arreglo interpretado en forma de caracter.